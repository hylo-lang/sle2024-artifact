/// A map from name expression to its referred declaration.
public typealias BindingMap = [NameExpr.ID: DeclReference]
