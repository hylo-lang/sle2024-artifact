/// An AST node that outlines a lexical scope.
public protocol LexicalScope {}
