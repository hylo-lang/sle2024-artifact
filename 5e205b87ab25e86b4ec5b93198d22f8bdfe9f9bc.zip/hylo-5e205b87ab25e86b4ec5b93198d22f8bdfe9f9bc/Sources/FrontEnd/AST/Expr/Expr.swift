/// A value expression.
public protocol Expr: Node {}
