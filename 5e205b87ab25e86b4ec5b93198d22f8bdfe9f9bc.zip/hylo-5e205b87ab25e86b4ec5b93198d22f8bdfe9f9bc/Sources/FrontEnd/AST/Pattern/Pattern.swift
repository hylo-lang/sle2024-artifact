/// A pattern.
public protocol Pattern: Node {}
