/// An identifier.
public typealias Identifier = String
