/// A statement.
public protocol Stmt: Node {}
