/// A member modifier.
public enum MemberModifier: Codable {

  /// The `static` member modifier.
  case `static`

}
