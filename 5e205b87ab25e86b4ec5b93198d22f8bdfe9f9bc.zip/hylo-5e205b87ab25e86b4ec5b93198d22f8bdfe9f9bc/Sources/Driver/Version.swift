// DO NOT COMMIT CHANGES TO THIS FILE
let hcVersion = "unknown"
