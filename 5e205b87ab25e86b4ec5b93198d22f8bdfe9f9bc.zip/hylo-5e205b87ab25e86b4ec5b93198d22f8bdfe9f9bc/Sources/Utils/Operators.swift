/// Concatenation
infix operator ++ : AdditionPrecedence

/// Type-erasure
prefix operator ^
