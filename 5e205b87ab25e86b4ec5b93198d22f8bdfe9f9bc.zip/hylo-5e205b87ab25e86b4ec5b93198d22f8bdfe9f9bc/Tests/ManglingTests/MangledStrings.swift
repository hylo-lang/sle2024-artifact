extension ManglingTests {

  static let inputCase =
    "mFxF0R0UfDynamicBufferA10sF06init1lTR736selfpT2bTa" +
    "TK1Z2gTK1G8HeadergTK1G9ElementacapacitypT1aTR2Zqin" +
    "itializing_header_withpT1lTgTrKG3E10pT2K4R7R7YVQOu" +
    ".fZlTtT112lTtT215rT1K9dinit_headerrT1Ke10pT2tT215K" +
    "9gpayload_headerK4R70R72K9tT13cKj"

}
